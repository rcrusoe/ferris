/**
 * You can configure theme options in this file.
 * Please refer to the documentation for more information.
 */

/************** Comments **************/

var disqus = "";

/************** Lightbox **************/

var lightbox = false;

/*********** Infinite Scroll **********/

var infinite_scroll = "";

/************ Social Media ************/

var facebook_link = "https://www.facebook.com";
var twitter_link = "https://www.twitter.com";
var google_plus_link = "https://plus.google.com/";
var dribbble_link = "";
var instagram_link = "https://instagram.com/";
var tumblr_link = "";
var youtube_link = "";
var vimeo_link = "";
var pinterest_link = "";
var flickr_link = "";
var linkedin_link = "";
var github_link = "";
var rss_link = false;